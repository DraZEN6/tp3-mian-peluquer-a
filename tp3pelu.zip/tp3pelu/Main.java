package tp3pelu;

public class Main {
    public static void main(String[] args) {
        Peluqueria peluqueria = new Peluqueria();
        peluqueria.iniciarMenuPrincipal();
    }
}
