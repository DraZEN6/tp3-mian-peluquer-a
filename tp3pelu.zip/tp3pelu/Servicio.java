package tp3pelu;

public class Servicio {
    private String nombreServicio;
    private double precio;

    public Servicio(String nombreServicio, double precio) {
        this.nombreServicio = nombreServicio;
        this.precio = precio;
    }

    public String getNombreServicio() {
        return nombreServicio;
    }

    public double getPrecio() {
        return precio;
    }

    public void mostrarServicio() {
        System.out.println("Servicio: " + nombreServicio + " - Precio: $" + precio);
    }
}
