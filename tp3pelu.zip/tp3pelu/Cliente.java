package tp3pelu;

public class Cliente extends Persona {
    private String telefono;
    private String direccion;
    private String dni;
    private int edad;

    public Cliente(String nombre, String email, String telefono, String direccion, String dni, int edad) {
        super(nombre, email);
        this.telefono = telefono;
        this.direccion = direccion;
        this.dni = dni;
        this.edad = edad;
    }

    // Métodos getter y setter
    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    // Agregar setNombre y setEmail
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    
    public void mostrarDatos() {
        System.out.println("Cliente: " + nombre + ", Email: " + email + ", Teléfono: " + telefono + ", Dirección: " + direccion + ", DNI: " + dni + ", Edad: " + edad);
    }
}
